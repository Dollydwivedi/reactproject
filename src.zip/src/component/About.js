import React from 'react';
import './About.js';
import download from '../assets/download.png'
export default function About() {
  return (
    <div>
    <h1>Abouts</h1>
     <img src={download}  alt="pics" width="300px"/>
    </div>
  );
}


