import React from 'react';
import './Termsconditions.js';



export default function Termsconditions() {
  return (
    <div>
    <h1>Terms</h1>
     </div>
  );
}
