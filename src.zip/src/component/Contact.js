import React, { useState } from 'react';
import './Contact.js';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';


export default function Contact() {
  const [validated, setValidated] = useState(false);

  const handleSubmit = (event) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };
  return (
    <>
    <div className="contact_header">
     <div className="contact_login text-center">
       <h1>Contact Us</h1>
    </div>
    <div className="contact_pages">
    <Container className='bg_contact'>
      <Row>
        <Col className='bgcontactss'>
        <div className="contact_address">
          <div className="text_react"> 
          <p class="text_addresss">Address:</p>   
            <p class="text_add">2nd Floor, Venkatadri IT Park, HP Avenue, Konnappana Agrahara, Electronic city, Bangalore -India 560</p>
         </div>
         <div className="text_react">
         <p class="text_addresss">Email:</p>     
         <p class="email_contact">xyz123@gmail.com</p>
         </div>
         <div className="text_react">
         <p class="text_addresss">Contact:</p>   
         <p class="">91+ 9187654321</p>
         </div>
        </div>
        </Col>
        <Col>
        <div className="contact_log ">
        <Form noValidate validated={validated} onSubmit={handleSubmit}>
        <div className="contact_address_1">
         <h6 className="getand">Get In <span className="touchsss">Touch</span></h6>
        </div>
          <Row className="mb-3">
          <Form.Group as={Col} md="12" controlId="validationCustom01">
          <Form.Label className="fistname">Full Name</Form.Label>
          <Form.Control
            required
            type="text"
            placeholder="enter name"
            defaultValue=""
          />
          <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
        </Form.Group>
        <Form.Group as={Col} md="12" controlId="validationCustom02">
          <Form.Label className="fistname">Email</Form.Label>
          <Form.Control
            required
            type="email"
            placeholder="enter email"
            defaultValue=""
          />
          </Form.Group>
          <Form.Group as={Col} md="12" controlId="validationCustom02">
        <Form.Label className="fistname">Massage</Form.Label>
        <Form.Control
          as="textarea"
          placeholder="enter Massage"
          style={{ height: '100px' }}
        />
          </Form.Group>
          </Row>
      <Button type="submit" className='btn_send'>Send</Button>
    </Form>
    </div>
    </Col>
      </Row>
      </Container>
      </div>
  </div>
    
    </>
  );
}
