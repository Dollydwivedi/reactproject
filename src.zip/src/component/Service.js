import React from 'react';
import './Service.js';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import makss from '../assets/makss.png';
import Testimonials from "../component/Testimonials";
export default function Service() {
  return (
    <div>
   <div className="contact_header">
     <div className="contact_login text-center">
       <h1>Service</h1>
    </div>
    </div>
    <div className='services_hm'>
        <Container>
        <Row className='serviresss_pd'>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>Design Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>

              </div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>SEO Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>
              </div>
            </Col>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
          </Row>
          <Row className='serviresss_pd'>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>Internet Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>

              </div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>BackLinks Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>
              </div>
            </Col>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
          </Row>
          <Row className='serviresss_pd'>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>Social Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>

              </div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>Design Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>
              </div>
            </Col>
            <Col lg='2' xs='12'>
              <div className='features_text'></div>
            </Col>
          </Row>
        </Container>
      </div>
      <div className='services_hm_s'>
        <Container>
          <Row>
            <Col lg='12' xs='12'>
            <div class="Testimonials_h">
            <button type="text" class="featurs_btn">STATE</button>
            <h1 class="headings">State</h1>
            </div>
            </Col>
          </Row>

          <Row>
            <Col lg='2' xs='12'><div className='features_text'></div> </Col>
            <Col lg='8' xs='12'>
              <div className='features_text'>
                <p className='textss_testm'>Far far away, behind the word mountains, far from the countries
                  Vokalia and Consonantia, there live the blind texts. Separated
                  they live in Bookmarksgrove right at
                  the coast of the Semantics, a large language ocean.</p>
              </div>
            </Col>
            <Col lg='2' xs='12'><div className='features_text'></div> </Col>
          </Row>
          </Container>
          </div>
          <Testimonials />
    </div>
  );
}
