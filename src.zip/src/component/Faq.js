import { useState } from "react";
import './Faq.js';



export default function Faq() {
  const[count, setCount]=useState(0)
  function increment(){
    setCount(count+1)
  }
  function decrement(){
    setCount(count-1)
  }
  return (
    <>
      <div className='faqmain'>
       <button onClick={increment}>+</button>
        {count}
       <button onClick={decrement}>-</button>
      </div>
    </>
  );
}
