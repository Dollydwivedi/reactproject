import React, { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Dropdown from 'react-bootstrap/Dropdown';
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';
import './Header.js';
import Login from "../component/Login";
export default function Header() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <>
      <div className='topHaeder'>
        <div className="container-fluid">
          <div className="row">
            <div className="col-10 mx-auto">
              <Navbar expand="lg">
               
                <Navbar.Brand href="/" className='logo'>
                  ECHO</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav-s" className="react_navbars ">
                  <Nav className="navbass" >
                    <Link to="/" className='navbarss'>Home</Link>
                   
                      <Dropdown>
                        <Dropdown.Toggle   id="dropdown-basic" className='dropdownss'>
                        dropdown
                        </Dropdown.Toggle>
                        <Dropdown.Menu className='dropdownss_manus'>
                          <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                          <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                          <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                      
                    <Link to="/about" className='navbarss'>About</Link>
                    <Link to="/service" className='navbarss'>Service</Link>
                    <Link to="/faq" className='navbarss'>FAQ</Link>
                    <Link to="/contact" className='navbarss'>Contact us</Link>
                  </Nav>
                </Navbar.Collapse>
                <Button className="loginbtn" onClick={handleShow}>Login Now</Button>
              </Navbar>
            </div>
          </div>
        </div>
      </div>
      <div className='modellogin btnlogins'>
      <Modal show={show} onHide={handleClose} className="modelbtns">
        <Modal.Body closeButton className='loginmodel'>
          <Login/>
        </Modal.Body>
       </Modal>
      </div>

    </>
  );
}


