import React from 'react';
import './Terms.js';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';


export default function Terms() {
  return (
    <>
    <div className='terms_conditionsp'>
    <Container>
        <Row>
            <Col>
            <div className='terms_head'>
            <h1 className='termsand'>Terms And Condition</h1>
        </div>
            </Col>
        </Row>
    <Row>
    <Col sx='12'>
           <div className='terms_conditions'>
       <div className='terms_text'>
            <h5 className='terms_tets'>What Are the Terms and Conditions and When Are They Needed?</h5>
            <ul className='ternsss'>
           <li className='texterms'>Particular emphasis should be given to the limitation of liability clauses (and disclaimers) , 
            for example the case of malfunctions of the app or website.</li>
            <li className='texterms'>The Terms and Conditions therefore, represent the document that helps in dealing with problems or 
                preventing them in the first place. Because of that, the Terms and Conditions are fundamental 
                in many cases in order to mount an adequate and proper defense.</li>
                <li className='texterms'>Particular emphasis should be given to the limitation of liability clauses (and disclaimers) , 
            for example the case of malfunctions of the app or website.</li>
            <li className='texterms'>Particular emphasis should be given to the limitation of liability clauses (and disclaimers) , 
            for example the case of malfunctions of the app or website.</li>
            </ul>
        </div>
    </div>
    </Col>
        </Row>
    <Row>
    <Col sx='12'>
           <div className='terms_conditions'>
        
        <div className='terms_text'>
            <h5 className='terms_tets'>What should I do if I run an e-commerce
             website? Is it recommended to create a Terms and Conditions document?</h5>
            <ul className='ternsss'>
           <li className='texterms'>Particular emphasis should be given to the limitation of liability clauses (and disclaimers) , 
            for example the case of malfunctions of the app or website.</li>
            <li className='texterms'>The Terms and Conditions therefore, represent the document that helps in dealing with problems or 
                preventing them in the first place. Because of that, the Terms and Conditions are fundamental 
                in many cases in order to mount an adequate and proper defense.</li>
                <li className='texterms'>Particular emphasis should be given to the limitation of liability clauses (and disclaimers) , 
            for example the case of malfunctions of the app or website.</li>
            <li className='texterms'>Particular emphasis should be given to the limitation of liability clauses (and disclaimers) , 
            for example the case of malfunctions of the app or website.</li>
            </ul>
        </div>
    </div>
    </Col>
        </Row>
    </Container>
    </div>
    </>
  );
}
