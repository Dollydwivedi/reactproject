import React from 'react';
import './Blog.js';


export default function Blog() {
 
  return (
    <div>
  
    </div>
  );
}
