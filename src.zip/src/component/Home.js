import React from 'react';
import './Home.js';
import background_bg from '../assets/background_bg.jpg'
import sliderimg from '../assets/sliderimg.jpeg'
import Carousel from 'react-bootstrap/Carousel';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import makss from '../assets/makss.png';
import marking from '../assets/marking.png';
import seo from '../assets/seo.png';
import abouts from '../assets/abouts.jpeg';
import { Link } from 'react-router-dom';
import Testimonials from "../component/Testimonials";
export default function App() {

  return (
    <>
      <div className='slider_index'>
        <Carousel>
          <Carousel.Item>
            <img src={background_bg} alt="pics" width="100%" height="500px" />
            <Carousel.Caption>
              <h1 className='slider_head'>Expert SEO, SEM Services in London</h1>
              <p className='slider_para'>
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove
                right at the coast of the Semantics, a large language ocean.
              </p>
              
              <Button className="loginbtn" >How we work</Button>
              <Button className="loginbtn_1" >Contact Us</Button>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img src={sliderimg} alt="pics" width="100%" height="500px" />

            <Carousel.Caption>
              <h1 className='slider_head'>Expert SEO, SEM Services in London</h1>
              <p className='slider_para'>
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove
                right at the coast of the Semantics, a large language ocean.
              </p>
              <Button className="loginbtn" >How we work</Button>
              <Button className="loginbtn_1" >Contact Us</Button>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img src={background_bg} alt="pics" width="100%" height="500px" />

            <Carousel.Caption>
              <h1 className='slider_head'>Expert SEO, SEM Services in London</h1>
              <p className='slider_para'>
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove
                right at the coast of the Semantics, a large language ocean.
              </p>
              <Button className="loginbtn" >How we work</Button>
              <Button className="loginbtn_1" >Contact Us</Button>
            </Carousel.Caption>
          </Carousel.Item>
        </Carousel>
      </div>

      <div className='features_hm'>
        <Container>
          <Row>
            <Col lg='12' xs='12'>
              <div className='features_h'>
                <Button type="text" className='featurs_btn'>FEATURES</Button>
                <h1 className='headings'>Our Features</h1>
              </div>
            </Col>
          </Row>

          <Row>
            <Col lg='4' xs='12'><div className='features_text'></div> </Col>
            <Col lg='4' xs='12'>
              <div className='features_text'>
                <p className='textss'>Far far away, behind the word mountains, far from the countries
                  Vokalia and Consonantia, there live the blind texts. Separated
                  they live in Bookmarksgrove right at
                  the coast of the Semantics, a large language ocean.</p>
              </div>
            </Col>
            <Col lg='4' xs='12'><div className='features_text'></div> </Col>
          </Row>


          <Row className='card_fts'>
            <Col lg='4' xs='12'> <div className='features_home'>
              <img src={marking} alt="pics" className='img-responsive imgdownl imgdownl_1' />
              <h6 className='mark_ft'>Marketing Analysis</h6>
              <p className='textss_hm'>Far far away, behind the word mountains, far
                from the countries Vokalia and Consonantia, there live the blind texts.</p>
            </div> </Col>
            <Col lg='4' xs='12'>
              <div className='features_home'>
                <img src={makss} alt="pics" className='img-responsive imgdownl' />
                <h6 className='mark_ft'>Digital Marketing</h6>
                <p className='textss_hm'>Far far away, behind the word mountains, far
                  from the countries Vokalia and Consonantia, there live the blind texts.</p>
              </div>
            </Col>
            <Col lg='4' xs='12'> <div className='features_home'>
              <img src={seo} alt="pics" className='img-responsive imgdownl' />
              <h6 className='mark_ft'>SEO and Backlinks</h6>
              <p className='textss_hm'>Far far away, behind the word mountains,
                far from the countries Vokalia and
                Consonantia, there live the blind texts.</p>
            </div>
            </Col>
          </Row>
        </Container>
      </div>

      <div className='features_aboutsss'>
        <Container>
          <Row>
            <Col lg='7' xs='12'><div className='features_about'>
              <img src={abouts} alt="pics" className='img-responsive imgdownl_abouts' /></div> </Col>
            <Col lg='5' xs='12'>
              <div className='aboutsss_text'>
                <Button type="text" className='featurs_btn'>ABOUTS US</Button>
                <h1 className='headings_abouts '>Why our <br />agency?</h1>
                <p className='textss_abouts'>Separated they live in Bookmarksgrove right at the coast of the Semantics, a
                  large language ocean.</p>
                <p className='textss_abouts_1'>Far far away, behind the word mountains,
                  far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in
                  Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                <Link to="/about" className='abouts_ft'>About</Link>
              </div>
            </Col>
          </Row>
        </Container>
      </div>

      <div className='services_hm'>
        <Container>
          <Row>
            <Col lg='12' xs='12'>
              <div className='features_h'>
                <Button type="text" className='featurs_btn'>SERVICES</Button>
                <h1 className='headings_s'>Our Services</h1>
              </div>
            </Col>
          </Row>
          <Row className='serviresss_pd'>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>Design Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>

              </div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>SEO Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>
              </div>
            </Col>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
          </Row>
          <Row className='serviresss_pd'>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>Internet Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>

              </div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>BackLinks Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>
              </div>
            </Col>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
          </Row>
          <Row className='serviresss_pd'>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>Social Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>

              </div>
            </Col>
            <Col lg='5' xs='12'>
              <div className='services_text'>
                <div className='serviess'>
                  <img src={makss} alt="pics" className='img-responsive img_servies' />
                </div>
                <div className='serviess'>
                  <h6 className='mark_ft'>Design Marketing</h6>
                  <p className='textss_ser'>Far far away, behind the word mountains, far from the countries
                    Vokalia and Consonantia, there live the blind texts.</p>
                </div>
              </div>
            </Col>
            <Col lg='1' xs='12'>
              <div className='features_text'></div>
            </Col>
          </Row>
        </Container>
      </div>
       <Testimonials />
    
    </>
  );
}


