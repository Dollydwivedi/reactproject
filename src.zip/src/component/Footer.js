import React from 'react';
import './Footer.js';

import Container from 'react-bootstrap/Container';
import { Link } from 'react-router-dom';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

export default function Footer() {
  return (
    <>
     
    <div className='footer'>

    <div className='footerlihnk'> 
    <Container>
      <Row>
        <Col xs="12" lg="4">
          <div class="menu-header">
          <h1 className='ft_logo'>ECHO</h1>
          <div className="contact_address_ft">
          <div className="text_react"> 
          <p class="text_addresss">Address:</p>   
            <p class="text_add">2nd Floor, Venkatadri IT Park, HP Avenue, Konnappana Agrahara, Electronic city, Bangalore -India 560</p>
         </div>
         <div className="text_react">
         <p class="text_addresss">Email:</p>     
         <p class="email_contact">xyz123@gmail.com</p>
         </div>
         <div className="text_react">
         <p class="text_addresss">Contact:</p>   
         <p class="">91+ 9187654321</p>
         </div>
        </div>
          </div>
        </Col>
        <Col xs="12" lg="2"></Col>
        <Col xs="12" lg="3">
          <div class="menu-header">
          
                   <nav className="navbass_ft" >
                   <h5>Pages</h5>
                    <ul className="ul_nav_ft">
                     <li className="li_nav_ft"><Link to="/" className='navbarss_ft'>Home</Link></li>
                     <li className="li_nav_ft"> <Link to="/about" className='navbarss_ft'>About</Link></li>
                     <li className="li_nav_ft"> <Link to="/service" className='navbarss_ft'>Service</Link> </li> 
                     <li className="li_nav_ft"><Link to="/faq" className='navbarss_ft'>FAQ</Link></li>
                     <li className="li_nav_ft"><Link to="/contact" className='navbarss_ft'>Contact us</Link></li>
                    </ul>
                  </nav>
          </div>
          </Col>
        <Col xs="12" lg="3">
          <div class="menu-header">
         
          <nav className="navbass_ft" >
                     <h5>Legal</h5>
                    <ul className="ul_nav_ft">
                     <li className="li_nav_ft"><Link to="/privacypolicy" className='navbarss_ft'>Privacy Policy </Link></li>
                     <li className="li_nav_ft"> <Link to="/terms" className='navbarss_ft'>Terms and Conditions </Link></li>
                    
                    </ul>
                  </nav>
          </div></Col>
       
      </Row>
    </Container>
    </div>
    <div className='footer_1'> 
    <p className="copyright py-2.5 text-center font-size: 1rem;">  
     © Copyright 2022 Echo.com All rights reserved.
      </p>
      </div>   
</div>
   
</>
  );
}


