import React from 'react';

import './Testimonial.js';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import img from '../assets/img.jpg';
import Slider from "react-slick";
export default function Testimonial() {
    const settings = {
        dots: true,
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        speed: 2000,
        autoplaySpeed: 2000,
        cssEase: "linear"
      };
  return (
    <div>
  <div className='Testimonials_hm'>
        <Container>
          <Row>
            <Col lg='12' xs='12'>
              <div className='Testimonials_h'>
              <button type="text" class="featurs_btn">Testimonials</button>
                <h1 className='headings'>Testimonials</h1>
              </div>
            </Col>
          </Row>

          <Row>
            <Col lg='2' xs='12'><div className='features_text'></div> </Col>
            <Col lg='8' xs='12'>
              <div className='features_text'>
                <p className='textss_testm'>Far far away, behind the word mountains, far from the countries
                  Vokalia and Consonantia, there live the blind texts. Separated
                  they live in Bookmarksgrove right at
                  the coast of the Semantics, a large language ocean.</p>
              </div>
            </Col>
            <Col lg='2' xs='12'><div className='features_text'></div> </Col>
          </Row>
          <Row className='card_fts'>
            
          </Row>

          <Row>
          <div id="slidesss">
              <Slider {...settings} >
                <div class="tns-item tns-slide-active" id="testimonial-slider-item1">
                  <div class="testimonial-v2">
                    <blockquote>
                      <p>“Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.”</p>
                    </blockquote>
                    <div class="author d-flex">
                      <div class="author-pic">
                      <img src={img}  alt="pics" width="30px"/>
                      </div>
                      <div class="author-name">
                        <h3>Drew Wood</h3>
                        <span>Director at Google</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="tns-item tns-slide-active" id="testimonial-slider-item1">
                  <div class="testimonial-v2">
                    <blockquote>
                      <p>“Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.”</p>
                    </blockquote>
                    <div class="author d-flex">
                    <div class="author-pic">
                      <img src={img}  alt="pics" width="30px"/>
                      </div>
                      <div class="author-name">
                        <h3>Drew Wood</h3>
                        <span>Director at Google</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tns-item tns-slide-active" id="testimonial-slider-item1">
                  <div class="testimonial-v2">
                    <blockquote>
                      <p>“Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.”</p>
                    </blockquote>
                    <div class="author d-flex">
                    <div class="author-pic">
                    <img src={img}  alt="pics" width="30px"/>
                      </div>
                      <div class="author-name">
                        <h3>Drew Wood</h3>
                        <span>Director at Google</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tns-item tns-slide-active" id="testimonial-slider-item1">
                  <div class="testimonial-v2">
                    <blockquote>
                      <p>“Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.”</p>
                    </blockquote>
                    <div class="author d-flex">
                    <div class="author-pic">
                      <img src={img}  alt="pics" width="30px"/>
                      </div>
                      <div class="author-name">
                        <h3>Drew Wood</h3>
                        <span>Director at Google</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Slider>
              </div>
            </Row>
        
        </Container>
      </div>
    </div>
  );
}
