import React, { useState } from "react";

import Form from "react-bootstrap/Form";
import Col from 'react-bootstrap/Col';
import Button from "react-bootstrap/Button";
import './Login.js';



export default function Login() {
    const [validated, setValidated] = useState(false);

    const handleSubmit = (event) => {
      const form = event.currentTarget;
      if (form.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      }
  
      setValidated(true);
    };
  
  return (
    <>
        <div className="Login">
            <div  className="loginhere"> <h4>Login In</h4></div>
      
<Form noValidate validated={validated} onSubmit={handleSubmit}>

<Form.Group as={Col} md="12" controlId="validationCustom02">
          <Form.Label className="fistname">Email</Form.Label>
          <Form.Control
            required
            type="email"
            placeholder="enter email"
            defaultValue=""
          />
          </Form.Group>
<Form.Group as={Col} md="12" controlId="validationCustom02">
          <Form.Label className="fistname">Password</Form.Label>
          <Form.Control
            required
            type="password"
            placeholder="enter Password"
            defaultValue=""
          />
          </Form.Group>
          
          <Button type="submit" className='btn_send signbtn'>Sign In</Button>

</Form>

</div> 
    </>
  );
}