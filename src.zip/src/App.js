import React from 'react';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";


import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import About from "./component/About";
import Home from "./component/Home";
import Blog from "./component/Blog";
import Contact from "./component/Contact";
import Service from "./component/Service";
import Footer from "./component/Footer";
import Header from "./component/Header";
import Terms from "./component/Terms";
import Privacypolicy from "./component/Privacypolicy"
import Faq from "./component/Faq"
export default function App() {
  return (
    <>
  
    <BrowserRouter>
    <Header/>
      <Routes>
        <Route exact path="/" element={<Home />} />
         <Route exact path="/blog" element={<Blog/>} />
          <Route  exact path="/contact" element={<Contact />} />
          <Route exact path="/about" element={<About />} />
          <Route exact path="/service" element={<Service />} />
          <Route exact path="/terms" element={<Terms />} />
          <Route exact path="/privacypolicy" element={<Privacypolicy />} />
          <Route exact path="/faq" element={<Faq />} />
      </Routes>
      <Footer/>
    </BrowserRouter>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);

              
